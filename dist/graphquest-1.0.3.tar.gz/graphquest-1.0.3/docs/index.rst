.. include:: ../README.rst

Contents
--------

.. toctree::

   Home <self>
   usage
   api
