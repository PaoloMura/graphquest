Examples
========

.. _example_question_types:

Question Types
--------------

QTextInput:

.. image:: images/QTextInput
    :width: 500
    :alt: An example of how QTextInput questions are displayed.

QMultipleChoice:

.. image:: images/QMultipleChoice
    :width: 500
    :alt: An example of how QMultipleChoice questions are displayed.

QVertexSet:

.. image:: images/QVertexSet
    :width: 500
    :alt: An example of how QVertexSet questions are displayed.

QEdgeSet:

.. image:: images/QEdgeSet
    :width: 500
    :alt: An example of how QEdgeSet questions are displayed.

QSelectPath:

.. image:: images/QSelectPath
    :width: 500
    :alt: An example of how QSelectPath questions are displayed.

